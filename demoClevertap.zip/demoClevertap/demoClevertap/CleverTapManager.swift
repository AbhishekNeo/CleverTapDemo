//
//  CleverTapManager.swift
//  demoClevertap
//
//  Created by Abhishek Singh on 19/04/22.
//

import Foundation
import CleverTapSDK

/**
 Singleton class to manage all Clever tap operations
 */
class CleverTapManager : NSObject {
    
    //1. Global shared insrance
    static let shared = CleverTapManager ()
    
    //2. Event triggers available
    enum EVENT_NAME : String {
        case PRODUCT_VIEW = "Product Viewed"
        case PUSH_RECEIVED = "PUSH_RECEIVED"
    }
    
    //3. Private constructor to avoid object creation from outside
    private override init () {
        
    }
    
    //4. Setup Cleaver tap SDK
    func setupCleaverTap () {
        
        
        
        // Configure and init an additional instance
        let ctConfig = CleverTapInstanceConfig.init(accountId: "884-5K7-RK6Z", accountToken: "a35-4bb")
        ctConfig.logLevel = .off
        ctConfig.disableIDFV = true
        let cleverTapAdditionalInstance = CleverTap.instance(with: ctConfig)
        NSLog("additional CleverTap instance created for accountID: %@", cleverTapAdditionalInstance.config.accountId)
        
        cleverTapAdditionalInstance.setPushNotificationDelegate(self)
        
//        // watchOS session
//        checkSession()
        
//        return true
        CleverTap.autoIntegrate()
    }
    
    /**
     This function is used to track custom events with Cleaver Tap
     - parameter param: Custom values.
     -  parameter eventName: Name of the custom event

     */
    func trackEvent (with param : [String : Any]? = nil,
                     eventName : EVENT_NAME) {
        guard let param = param else {return}
        CleverTap.sharedInstance()?.recordEvent(eventName.rawValue,
                                                withProps: param)
        
    }
    
    /**
     This function is used tosetup Cleaver tap with device token
     - parameter token: APNS token

     */    func setupPushToken (with token : NSData) {
        CleverTap.sharedInstance()?.setPushToken(token as Data)

     }
    
    func handleNotification (with data : Any) {
        CleverTap.sharedInstance()?.handleNotification (withData: data)
    }
    
    
    
    
}
extension CleverTapManager : CleverTapPushNotificationDelegate {
    func pushNotificationTapped(withCustomExtras customExtras: [AnyHashable : Any]!) {
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: EVENT_NAME.PUSH_RECEIVED.rawValue),
                                        object: nil,
                                        userInfo: customExtras)
        
    }
    
}
