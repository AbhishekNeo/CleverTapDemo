//
//  ViewController.swift
//  demoClevertap
//
//  Created by Abhishek Singh on 18/04/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func subMitPressed(_ sender: Any) {
        
        let param : [String : Any] = [
            "product_id" : 2,
            "product_image" : "https://d35fo82fjcw0y8.cloudfront.net/2018/07/26020307/customer-success-clevertap.jpg",
            "product_name" : "CleverTap2",
            "email" : "asabhishek82@yahoo.com"
        ]
        
        CleverTapManager.shared.trackEvent(with: param,
                                           eventName: .PRODUCT_VIEW)
        
    }
    
    
}

